/* Копилка — надёжная версия */
'use strict';

const STORAGE_KEY = 'kopilka_v2';
const OLD_STORAGE_KEY = 'kopilka_v1';

const I18N = {
  ru: {
    appName:'Копилка', appTag:'Мои деньги — мои накопления', pageTitle:'Твоя копилка', pageSub:'Копи. Сохраняй. Достигай.',
    balanceLabel:'Текущий баланс', currency:'сум', income:'Пополнено', expense:'Снято', tabAdd:'Пополнить', tabWithdraw:'Снять',
    amountLabel:'Сумма (сум)', amountPh:'Введите сумму', addBtn:'Добавить деньги', withdrawBtn:'Снять деньги',
    historyLabel:'История операций', historyEmpty:'Пока нет операций — сделай первый шаг 🌱', txAdd:'Пополнение', txWithdraw:'Снятие',
    errAmount:'Введите корректную сумму', errFunds:'Недостаточно средств в копилке', okAdd:'Добавлено', okWithdraw:'Снято',
    resetTitle:'Сбросить все данные', confirmReset:'Точно сбросить копилку? Вся история удалится.', footerText:'Маленькие шаги каждый день приводят к большим результатам'
  },
  uz: {
    appName:"Jamg'arma", appTag:"Mening pulim — mening jamg'armam", pageTitle:"Sening jamg'armang", pageSub:"To'pla. Saqla. Erish.",
    balanceLabel:'Joriy balans', currency:"so'm", income:"To'ldirildi", expense:'Yechildi', tabAdd:"To'ldirish", tabWithdraw:'Yechish',
    amountLabel:"Summa (so'm)", amountPh:'Summani kiriting', addBtn:"Pul qo'shish", withdrawBtn:'Pul yechish',
    historyLabel:'Amallar tarixi', historyEmpty:"Hozircha amallar yo'q — ilk qadamni tashlang 🌱", txAdd:"To'ldirish", txWithdraw:'Yechish',
    errAmount:"To'g'ri summa kiriting", errFunds:'Jamg‘armada mablag‘ yetarli emas', okAdd:"Qo'shildi", okWithdraw:'Yechildi',
    resetTitle:"Barcha ma'lumotlarni tozalash", confirmReset:"Jamg'armani tozalaysizmi? Butun tarix o'chadi.", footerText:'Har kungi kichik qadamlar katta natijalarga olib boradi'
  }
};

const defaultState = () => ({ balance:0, lang:'ru', txs:[] });
let state = loadState();
let mode = 'add';

function loadState(){
  try {
    const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem(OLD_STORAGE_KEY);
    if (!raw) return defaultState();
    const s = JSON.parse(raw);
    return {
      ...defaultState(),
      ...s,
      balance: Number.isFinite(Number(s.balance)) ? Math.max(0, Number(s.balance)) : 0,
      txs: Array.isArray(s.txs) ? s.txs.filter(x => x && (x.type === 'add' || x.type === 'withdraw') && Number(x.amount) > 0) : []
    };
  } catch(e) { return defaultState(); }
}
function saveState(){
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch(e) {
    // Некоторые браузеры ограничивают storage для file://; приложение всё равно продолжает работать.
  }
}
function $(id){ return document.getElementById(id); }
const els = {
  balanceValue:$('balanceValue'), floatBalance:$('floatBalance'), incomeValue:$('incomeValue'), expenseValue:$('expenseValue'),
  moneyFill:$('moneyFill'), moneyStack:$('moneyStack'), moneySurface:$('moneySurface'), coinLayer:$('coinLayer'),
  tabAdd:$('tabAdd'), tabWithdraw:$('tabWithdraw'), amountInput:$('amountInput'), actionBtn:$('actionBtn'), actionBtnText:$('actionBtnText'),
  historyList:$('historyList'), historyEmpty:$('historyEmpty'), historyCount:$('historyCount'), toast:$('toast'), resetBtn:$('resetBtn')
};

function fmt(n){ return Math.round(Number(n)||0).toString().replace(/\B(?=(\d{3})+(?!\d))/g,' '); }
function fmtDate(ts){
  const d = new Date(ts); const loc = state.lang === 'uz' ? 'uz-UZ' : 'ru-RU';
  return d.toLocaleDateString(loc,{day:'numeric',month:'short'})+', '+d.toLocaleTimeString(loc,{hour:'2-digit',minute:'2-digit'});
}
function t(key){ return I18N[state.lang]?.[key] || I18N.ru[key] || key; }

function applyLang(){
  document.documentElement.lang = state.lang;
  document.querySelectorAll('[data-i18n]').forEach(el => { const k=el.dataset.i18n; if(t(k)) el.textContent=t(k); });
  document.querySelectorAll('[data-i18n-ph]').forEach(el => { const k=el.dataset.i18nPh; el.placeholder=t(k); });
  document.querySelectorAll('[data-i18n-title]').forEach(el => { const k=el.dataset.i18nTitle; el.title=t(k); });
  document.querySelectorAll('.lang-btn').forEach(b=>b.classList.toggle('lang-btn--active',b.dataset.lang===state.lang));
  updateTabUI(); render();
}

function render(){
  els.balanceValue.textContent=fmt(state.balance);
  els.floatBalance.textContent=fmt(state.balance);
  let inc=0, exp=0;
  state.txs.forEach(tx=>tx.type==='add' ? inc+=Number(tx.amount) : exp+=Number(tx.amount));
  els.incomeValue.textContent=fmt(inc)+' '+t('currency');
  els.expenseValue.textContent=fmt(exp)+' '+t('currency');
  renderMoneyStack(); renderHistory();
}

function renderMoneyStack(){
  els.moneyStack.innerHTML=''; els.moneySurface.innerHTML='';
  if(state.balance<=0){ els.moneyFill.style.height='0%'; return; }
  // В банке высота растёт постепенно и не зависит от удалённой цели.
  const visual = Math.min(88, 12 + Math.log10(state.balance + 1) * 15);
  els.moneyFill.style.height=visual+'%';
  const stackH=els.moneyFill.clientHeight||120, jarW=els.moneyFill.clientWidth||240, gap=13;
  const count=Math.min(22,Math.max(3,Math.floor(stackH/gap)));
  for(let i=0;i<count;i++){
    const b=document.createElement('div'); b.className='bill'; b.textContent='$';
    b.style.left=Math.max(4,Math.random()*Math.max(10,jarW-70))+'px';
    b.style.bottom=(i*gap)+'px'; b.style.transform=`rotate(${(Math.random()*14-7).toFixed(1)}deg)`; b.style.zIndex=i;
    els.moneyStack.appendChild(b);
  }
  const coins=Math.min(5,Math.max(1,Math.round(count/5)));
  for(let i=0;i<coins;i++){
    const c=document.createElement('div'); c.className='coin-float'; c.textContent='$';
    c.style.left=(10+Math.random()*Math.max(10,jarW-45))+'px'; c.style.top='-26px';
    c.style.animationDelay=(Math.random()*1.5).toFixed(2)+'s'; els.moneySurface.appendChild(c);
  }
}

function renderHistory(){
  els.historyList.innerHTML=''; const txs=[...state.txs].reverse().slice(0,50);
  els.historyCount.textContent=state.txs.length ? state.txs.length : '';
  els.historyEmpty.style.display=txs.length?'none':'block';
  txs.forEach(tx=>{
    const li=document.createElement('li'); li.className='history-item'; const isIn=tx.type==='add';
    li.innerHTML=`<div class="h-icon ${isIn?'h-icon--in':'h-icon--out'}">${isIn?'+':'−'}</div>
      <div class="h-body"><div class="h-label">${t(isIn?'txAdd':'txWithdraw')}</div><div class="h-date">${fmtDate(tx.date)}</div></div>
      <div class="h-amount ${isIn?'h-amount--in':'h-amount--out'}">${isIn?'+':'−'} ${fmt(tx.amount)} ${t('currency')}</div>`;
    els.historyList.appendChild(li);
  });
}

function dropCoins(amount){
  const jarH=$('jarBody')?.clientHeight||380, jarW=els.coinLayer.clientWidth||240;
  const count=Math.min(14,Math.max(5,Math.round(amount/150000)));
  for(let i=0;i<count;i++){
    const c=document.createElement('div'); c.className='coin-drop'; c.textContent='$';
    c.style.left=(6+Math.random()*Math.max(10,jarW-36))+'px'; c.style.setProperty('--dur',(0.7+Math.random()*0.5).toFixed(2)+'s');
    c.style.setProperty('--fall',(jarH*(0.55+Math.random()*0.4)).toFixed(0)+'px'); c.style.animationDelay=(Math.random()*0.25).toFixed(2)+'s';
    els.coinLayer.appendChild(c); setTimeout(()=>c.remove(),1700);
  }
}

let toastTimer;
function showToast(msg,type){ els.toast.textContent=msg; els.toast.className='toast show'+(type?' toast--'+type:''); clearTimeout(toastTimer); toastTimer=setTimeout(()=>els.toast.classList.remove('show'),2600); }

function updateTabUI(){
  els.tabAdd.classList.toggle('tab--active',mode==='add'); els.tabWithdraw.classList.toggle('tab--active',mode==='withdraw');
  els.tabWithdraw.classList.toggle('tab--withdraw',mode==='withdraw'); els.actionBtn.classList.toggle('withdraw-mode',mode==='withdraw');
  els.actionBtnText.textContent=t(mode==='add'?'addBtn':'withdrawBtn'); els.actionBtn.querySelector('.action-btn-icon').textContent=mode==='add'?'+':'−';
}
function parseAmount(){ return Math.floor(Number(String(els.amountInput.value).replace(/\s/g,'').replace(/[^0-9]/g,''))||0); }
function addAmountToInput(n){ els.amountInput.value=fmt(Math.max(0,parseAmount()+Number(n))); els.amountInput.classList.remove('err'); }

els.tabAdd.addEventListener('click',()=>{mode='add';updateTabUI();});
els.tabWithdraw.addEventListener('click',()=>{mode='withdraw';updateTabUI();});
els.amountInput.addEventListener('input',()=>{ const n=parseAmount(); els.amountInput.value=n?fmt(n):''; els.amountInput.classList.remove('err'); });
els.amountInput.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();els.actionBtn.click();}});
document.querySelectorAll('.chip').forEach(chip=>chip.addEventListener('click',()=>addAmountToInput(chip.dataset.amount)));

els.actionBtn.addEventListener('click',()=>{
  const amount=parseAmount();
  if(amount<=0){ els.amountInput.classList.add('err'); els.amountInput.focus(); showToast(t('errAmount'),'error'); return; }
  if(mode==='withdraw' && amount>state.balance){ els.amountInput.classList.add('err'); showToast(t('errFunds'),'error'); return; }
  if(mode==='add'){ state.balance+=amount; dropCoins(amount); showToast(`${t('okAdd')}: + ${fmt(amount)} ${t('currency')}`,'success'); }
  else { state.balance-=amount; showToast(`${t('okWithdraw')}: − ${fmt(amount)} ${t('currency')}`,'success'); }
  state.txs.push({type:mode,amount,date:Date.now()}); if(state.txs.length>300) state.txs=state.txs.slice(-300);
  els.amountInput.value=''; saveState(); render();
});

els.resetBtn.addEventListener('click',()=>{
  if(confirm(t('confirmReset'))){ const lang=state.lang; state=defaultState(); state.lang=lang; saveState(); render(); showToast('OK','success'); }
});
document.querySelectorAll('.lang-btn').forEach(btn=>btn.addEventListener('click',()=>{state.lang=btn.dataset.lang==='uz'?'uz':'ru';saveState();applyLang();}));
window.addEventListener('resize',()=>{clearTimeout(window.__kopilkaResize);window.__kopilkaResize=setTimeout(renderMoneyStack,150);});

applyLang();
setTimeout(renderMoneyStack,80);
